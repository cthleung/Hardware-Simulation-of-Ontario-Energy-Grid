# PythonWebsocketServer_NodeMCUClient
Contains a Python WebSocket server and a Websocket client that can be uploaded to an ESP8266
